<div class="d-inline-block ms-2" id="ppi_action">
    <form action="" method="POST" id="ppi_action_form">
        @csrf
    
    
        <!-- ====================================================
               # Subordinate Manager Section
               # PPI Sent To Boss
               # PPI Correction(If Boss Dispute)
               # Direct PPI Sent To Warehouse Manager (If Boss Dispute)
            ========================================================= -->
        @if($generalUser && auth()->user()->hasRoutePermission('ppi_sent_to_boss_action'))
            @php
    
                $ppiStatusFormAction =  route('ppi_sent_to_boss_action', [$warehouse_code, $ppi->id, 'ppi_sent_to_boss']);
                $ppiStatusFormBtnText = 'Sent to Boss';
                $ppiStatusFormBtnClass = 'indigo';
                $ppiStatusFormBtnId = '';
                $ppiStatusCode = '';
                $warehouse_code = '';
                $doneThisAction = $Model('PpiSpiStatus')::checkPpiStatus($ppi->id, 'ppi_sent_to_boss');
                if($doneThisAction){
                    $doneThisActionButton = true;
                }
            @endphp
    
    
            <!-- ===============================
                # Boss Section
               # Boss Can Correction on Dispute Product
               # Boss can Sent to Warehouse Manager
            ==================================== -->
        @elseif($generalUser && auth()->user()->hasRoutePermission('ppi_sent_to_wh_manager_action'))
            @php
                if($checkPpiLastSts->code == 'ppi_sent_to_boss') {
                    $ppiStatusFormAction =  route('ppi_sent_to_wh_manager_action', [$warehouse_code, $ppi->id, 'ppi_sent_to_wh_manager']);
                    $ppiStatusFormBtnText = 'Sent to Warehouse Manager';
                    $ppiStatusFormBtnClass = 'indigo';
                    $ppiStatusFormBtnId = '';
                    $ppiStatusCode = '';
                    $warehouse_code = '';
                    $doneThisAction =   false;
                    $doneThisActionButton = false;
                } elseif($checkPpiLastSts->code  == 'ppi_sent_to_wh_manager'){
                    $doneThisAction =   true;
                    $doneThisActionButton = true;
                } elseif($checkPpiLastSts->code  == 'ppi_correction_done_by_boss') {
                    $ppiStatusFormAction =  route('ppi_resent_to_wh_manager_action', [$warehouse_code, $ppi->id, 'ppi_resent_to_wh_manager']);
                    $ppiStatusFormBtnText = 'Re Sent to Warehouse Manager';
                    $ppiStatusFormBtnClass = 'teal';
                    $ppiStatusFormBtnId = '';
                    $ppiStatusCode = '';
                    $warehouse_code = '';
                    $doneThisAction = false;
                    $doneThisActionButton = true;
                } elseif($checkPpiLastSts->code  == 'ppi_dispute_by_wh_manager'){
                    $doneThisAction =  true;
                    $doneThisActionButton = true;
                } elseif($checkPpiLastSts->code  == 'ppi_resent_to_wh_manager'){
                    $doneThisAction =   true;
                    $doneThisActionButton = true;
                } else {
                    $doneThisAction =   true;
                    $doneThisActionButton = true;
                }
            @endphp
    
    
    
            <!--==================================
                # Warehouse Manager  Section
                # He Can Dispute
                # He Can Check Existing product
                # He can Print Barcode
                # He cam stock in Product
            ====================================-->
        @elseif($generalUser && auth()->user()->hasRoutePermission('ppi_dispute_by_wh_manager_action'))
            @php
                $challanPdfDone = $Model('PpiSpiStatus')::checkPpiStatus($ppi->id, 'ppi_challan_pdf_printed');
        
                if($singleProductValidationDone && $setProductValidationDone && !$challanPdfDone){
                    // Step 1: Show Challan PDF button
                    $ppiStatusFormAction = route('ppi_challan_pdf_printed_now', [
                        'warehouse_code' => $warehouse_code,
                        'ppi_id'         => $ppi->id,
                        'status'         => 'ppi_challan_pdf_printed'
                    ]);
                    $ppiStatusFormBtnText = 'Generate Challan PDF';
                    $ppiStatusFormBtnClass = 'teal';
                    $ppiStatusFormBtnId = 'printChallanBtn';
                    $ppiStatusCode = 'ppi_challan_pdf_printed';
                    $warehouse_code = $warehouse_code;
                    $doneThisAction = false;
                    $doneThisActionButton = true;
        
                } elseif($singleProductValidationDone && $setProductValidationDone && $challanPdfDone){
                    // Step 2: After PDF generated, show Close PPI button
                    $ppiStatusFormAction = route('ppi_all_steps_complete_action', [$warehouse_code, $ppi->id, 'ppi_all_steps_complete']);
                    $ppiStatusFormBtnText = 'Close this PPI';
                    $ppiStatusFormBtnClass = 'indigo';
                    $ppiStatusFormBtnId = '';
                    $ppiStatusCode = '';
                    $doneThisAction = false;
                    $doneThisActionButton = true;
        
                } else {
                    $doneThisAction = true;
                    $doneThisActionButton = true;
                }
            @endphp
        @endif
    
    
        @php
            $ppiComplete = $Model('PpiSpiStatus')::getPpiLastStatus($ppi->id)->code;
            if($ppiComplete == 'ppi_all_steps_complete'){
                $doneThisAction =  true;
                $doneThisActionButton = true;
            }
        @endphp
    
    
    
    
        @php
            $globalUser =  auth()->user()->checkUserRoleTypeGlobal();
            if($globalUser && $singleProductValidationDone && $setProductValidationDone && $ppiComplete != 'ppi_all_steps_complete'){
                $ppiStatusFormAction =  route('ppi_all_steps_complete_action', [$warehouse_code, $ppi->id, 'ppi_all_steps_complete']);
                $ppiStatusFormBtnText = 'Close this PPI';
                $ppiStatusFormBtnClass = 'indigo';
                $doneThisAction =  false;
                $doneThisActionButton = false;
            }elseif($globalUser) {
                $doneThisAction = false;
                $doneThisActionButton = false;
            }
        @endphp
    
    
        <!-- Button For Action -->
        @isset($ppiStatusFormAction)
            @if(isset($doneThisAction) && $doneThisAction == false)
                <button type="button"
                        data-url="{{ $ppiStatusFormAction }}"
                        {{-- Only add modal if NOT PDF button --}}
                        @if($ppiStatusFormBtnId !== 'printChallanBtn')
                            data-bs-toggle="modal"
                            data-bs-target="#ppiActionModal"
                        @endif
                        class="btn btn-md btn-{{ $ppiStatusFormBtnClass }} text-white py-0"
                        id="{{ $ppiStatusFormBtnId }}"
                        data-status="{{ $ppiStatusCode }}"
                        data-ppi-id="{{ $ppi->id }}"
                        data-warehouse="{{ $warehouse_code }}">
                    {{ $ppiStatusFormBtnText }}
                </button>
            
                {!! 
                    $Component::confirmModal('ppiActionModal', 'form#ppi_action_form', 'Are you sure?', '', '') 
                !!}
            @endif

        @endisset

    </form>
</div>


@section('bottomjs')
    @parent
    <?php
    /**
     * ppi Elements Setup
     * Show / Hide or ANy Permission use for Button , row a
     */
    //echo $PpiSpiPermission::elements();
    ?>

    @if(isset($doneThisAction) && $doneThisAction === true)
        <script>
            $('#ppi_content .done_this_action').remove();
        </script>
    @endif

    @if(isset($doneThisActionButton) && $doneThisActionButton === true)
        <script>
            $('#ppi_content .done_this_action_btn').remove();
        </script>
    @endif



    <script>
        $('#ppi_action button').on('click', function () {
            // alert(1)
            let Url = $(this).attr('data-url');
            $('#ppi_action form#ppi_action_form').prop('action', Url);
        })
        $('#ppiActionModal').on('click', 'button.modal-cancel', function () {
            $('#ppi_action form#ppi_action_form').prop('action', '');
        })
        
    </script>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const btn = document.getElementById('printChallanBtn');
    
        if (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
    
                let warehouse = this.dataset.warehouse;
                let ppiId     = this.dataset.ppiId;
                let status    = this.dataset.status;
                
                // 1. Open PDF in new tab (GET route)
                window.open(`/ppi/${warehouse}/${ppiId}/${status}/challan/pdf`, "_blank");
                
                // 2. Mark status (POST route)
                fetch(`/ppi/${warehouse}/${ppiId}/${status}/challan-pdf`, {
                    method: "POST",
                    headers: {
                        "X-CSRF-TOKEN": "{{ csrf_token() }}",
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({})
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    }
                });

            });
        }
    });

    </script>
    
@endsection