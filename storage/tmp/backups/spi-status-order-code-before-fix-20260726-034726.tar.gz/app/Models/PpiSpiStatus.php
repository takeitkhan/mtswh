<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PpiSpiStatus extends Model
{
    use HasFactory;
    protected $table = 'ppi_spi_statuses';
    protected $fillable = [
        'ppi_spi_id', 'status_for', 'warehouse_id', 'code', 'action_performed_by', 'status_order', 'message', 'status_type', 'status_format', 'note', 'ppi_spi_product_id'
    ];

    public function ppispidispute(){
       return $this->hasMany('App\Models\PpiSpiDispute', 'ppi_spi_status_id', 'id');
    }
    
    public function performedBy()
    {
        return $this->belongsTo('App\Models\User', 'action_performed_by', 'id');
        // 'action_performed_by' is the foreign key in this table
        // 'id' is the local primary key in the users table
    }

    /**===================================
     * =============== PPI================
     ====================================*/


    /**
     * @param $ppi_id
     * @return null
     */
    public static function getPpiLastStatus($ppi_id, $option = []){
        $default = [
            'ppi_spi_product_id' => null,
            'code' => null,
            'status_format' => null,
        ];
        $merge = array_merge($default, $option);
        $status = PpiSpiStatus::where('ppi_spi_id', $ppi_id)
                            ->where('status_for', 'Ppi');
        if(!empty($merge['ppi_spi_product_id'])){
            $status = $status->where('ppi_spi_product_id', $merge['ppi_spi_product_id']);
        }
        if(!empty($merge['status_format'])){
            $status = $status->where('status_format', $merge['status_format']);
        }
        if(!empty($merge['code'])){
            $status = $status->where('code', $merge['code']);
        }
        $status = $status->orderBy('id', 'desc')
                     ->first();


        if(!empty($status)){
            return $status ?? null;
        } else {
            return NULL;
        }
    }

    /**
     * @param $ppi_id
     * @param $options
     * @return null
     */

    public static function getPpiLastMainStatus($ppi_id, $options = []){
        $default = [
            'ppi_spi_product_id' => null,
            'code' => null,
        ];
        $merge = array_merge($default, $options);
        $status = PpiSpiStatus::where('ppi_spi_id', $ppi_id)
                            ->where('status_for', 'Ppi')
                            ->where('status_format', 'Main');
        if($merge['ppi_spi_product_id']){
            $status = $status->where('ppi_spi_product_id' , $merge['ppi_spi_product_id']);
        }
        if(!empty($merge['code'])){
            $status = $status->where('code', $merge['code']);
        }
        $status = $status->orderBy('status_order', 'desc')
                        ->first();
        if(!empty($status)){
            return $status ?? null;
        } else {
            return NULL;
        }
    }

    /**
     * @param $ppi_id
     * @param $code
     * @return bool
     */
    public static function checkPpiStatus($ppi_id, $code, $option = []){
        $default = [
            'ppi_spi_product_id' => null,
        ];
        $merge = array_merge($default, $option);
        $status = PpiSpiStatus::where('ppi_spi_id', $ppi_id)->where('status_for', 'Ppi')
                            ->where('code', $code);
        if($merge['ppi_spi_product_id']){
            $status = $status->where('ppi_spi_product_id' , $merge['ppi_spi_product_id']);
        }
        $status = $status->orderBy('status_order', 'desc')
                    ->first();

        if(!empty($status)){
            return true;
        } else {
            return false;
        }
    }



    /**
     * checkMultiLastPpiStatus
     *
     * @param  mixed $ppi_id
     * @param  mixed $code
     * @return void
     */
    public static function checkMultiLastPpiStatus($ppi_id, $code = []){
        $status =  PpiSpiStatus::where('ppi_spi_id', $ppi_id)->where('status_for', 'Ppi')
                    ->whereIn('code', $code)
                    ->orderBy('status_order', 'desc')
                    ->first();
        if(!empty($status)){
            return $status->code;
        } else {
            return Null;
        }
    }





    /**================================
     * ====== SPI ====================
     ================================*/
    public static function getSpiLastStatus($spi_id, $option=[]){
        $default = [
            'ppi_spi_product_id' => null,
            'code' => null,
            'status_format' => null,
        ];
        $merge = array_merge($default, $option);
        $status = PpiSpiStatus::where('ppi_spi_id', $spi_id)
                        ->where('status_for', 'Spi');

        if(!empty($merge['ppi_spi_product_id'])){
            $status = $status->where('ppi_spi_product_id', $merge['ppi_spi_product_id']);
        }
        if(!empty($merge['status_format'])){
            $status = $status->where('status_format', $merge['status_format']);
        }
        if(!empty($merge['code'])){
            $status = $status->where('code', $merge['code']);
        }
        $status = $status->orderBy('status_order', 'desc')->first();

        if(!empty($status)){
            return $status;
        } else {
            return NULL;
        }
    }



    /**
     * @param $spi_id
     * @param $options
     * @return null
     */

    public static function getSpiLastMainStatus($spi_id, $options = []){
        $default = [
            'ppi_spi_product_id' => null,
            'code' => null,
        ];
        $merge = array_merge($default, $options);
        $status = PpiSpiStatus::where('ppi_spi_id', $spi_id)
            ->where('status_for', 'Spi')
            ->where('status_format', 'Main');
        if($merge['ppi_spi_product_id']){
            $status = $status->where('ppi_spi_product_id' , $merge['ppi_spi_product_id']);
        }
        if(!empty($merge['code'])){
            $status = $status->where('code', $merge['code']);
        }
        $status = $status->orderBy('id', 'desc')
            ->first();
        if(!empty($status)){
            return $status;
        } else {
            return NULL;
        }
    }
    /**
     * @param $spi_id
     * @param $code
     * @return bool
     */
    public static function checkSpiStatus($spi_id, $code, $option = []){
        $default = [
            'ppi_spi_product_id' => null,
        ];
        $merge = array_merge($default, $option);
        $status = PpiSpiStatus::where('ppi_spi_id', $spi_id)->where('status_for', 'Spi')
            ->where('code', $code);

        if($merge['ppi_spi_product_id']){
            $status = $status->where('ppi_spi_product_id' , $merge['ppi_spi_product_id']);
        }

        $status = $status->orderBy('status_order', 'desc')->first();
        if(!empty($status)){
            return true;
        } else {
            return false;
        }
    }



    /**================================
     * ===== DRAFT MODE FUNCTIONS ====
     ================================*/

    /**
     * DRAFT STATUS CODES
     * Statuses that allow Edit/Delete
     */
    const DRAFT_STATUS_CODES = [
        'ppi_draft',
        'spi_draft'
    ];

    /**
     * SUBMITTED STATUS CODES
     * Statuses that DON'T allow Edit/Delete
     */
    const SUBMITTED_STATUS_CODES = [
        'ppi_sent_to_boss',
        'spi_sent_to_boss',
        'ppi_sent_to_wh_manager',
        'spi_sent_to_wh_manager',
        'ppi_all_steps_complete',
        'spi_all_steps_complete',
    ];

    /**
     * Check if PPI/SPI is in DRAFT mode
     * @param $ppi_spi_id
     * @param $status_for - 'Ppi' or 'Spi'
     * @return bool
     */
    public static function isDraft($ppi_spi_id, $status_for = 'Ppi')
    {
        $lastStatus = PpiSpiStatus::where('ppi_spi_id', $ppi_spi_id)
                                ->where('status_for', $status_for)
                                ->where('status_format', 'Main')
                                ->orderBy('status_order', 'desc')
                                ->first();

        if (!$lastStatus) {
            return true; // New record is considered as draft
        }

        return in_array($lastStatus->code, self::DRAFT_STATUS_CODES);
    }

    /**
     * Check if PPI/SPI is SUBMITTED (cannot edit/delete)
     * @param $ppi_spi_id
     * @param $status_for - 'Ppi' or 'Spi'
     * @return bool
     */
    public static function isSubmitted($ppi_spi_id, $status_for = 'Ppi')
    {
        return !self::isDraft($ppi_spi_id, $status_for);
    }

    /**
     * Check if PPI/SPI can be EDITED
     * @param $ppi_spi_id
     * @param $status_for - 'Ppi' or 'Spi'
     * @return bool
     */
    public static function canEdit($ppi_spi_id, $status_for = 'Ppi')
    {
        return self::isDraft($ppi_spi_id, $status_for);
    }

    /**
     * Check if PPI/SPI can be DELETED
     * @param $ppi_spi_id
     * @param $status_for - 'Ppi' or 'Spi'
     * @return bool
     */
    public static function canDelete($ppi_spi_id, $status_for = 'Ppi')
    {
        return self::isDraft($ppi_spi_id, $status_for);
    }

    /**
     * Get current status information for PPI/SPI
     * @param $ppi_spi_id
     * @param $status_for - 'Ppi' or 'Spi'
     * @return object|null
     */
    public static function getCurrentStatus($ppi_spi_id, $status_for = 'Ppi')
    {
        return PpiSpiStatus::where('ppi_spi_id', $ppi_spi_id)
                            ->where('status_for', $status_for)
                            ->where('status_format', 'Main')
                            ->orderBy('status_order', 'desc')
                            ->first();
    }

    /**
     * Get Draft Status message for display
     * @param $ppi_spi_id
     * @param $status_for - 'Ppi' or 'Spi'
     * @return string
     */
    public static function getDraftStatusMessage($ppi_spi_id, $status_for = 'Ppi')
    {
        if (self::isDraft($ppi_spi_id, $status_for)) {
            return '✏️ DRAFT - Edit/Delete Allowed';
        }
        return '🔒 SUBMITTED - Locked (No Edit/Delete)';
    }

    /** Motification */
    public static function notifications($options = []){            	
        $default = [
            'count' => false,
            'paginate' => false,
            'is_read' => false,
            'warehouse_id' => false,
            'query' => false,
        ];
        $merge = array_merge($default, $options);
//        $role = request()->get('currentUserRole');
        $role = User::getWarehouseRoles(auth()->user()->id)->pluck('role_id');

        if($role){
            /**
            
            $query = PpiSpiStatus::leftjoin('ppi_spi_notifications', 'ppi_spi_notifications.status_id', 'ppi_spi_statuses.id')
                ->select('ppi_spi_statuses.*', 'ppi_spi_notifications.is_read')
                ->where('ppi_spi_statuses.status_format', 'Main')
                ->orderBy('id', 'desc');
          
          	**/
          	$query = PpiSpiStatus::leftjoin('ppi_spi_notifications', 'ppi_spi_notifications.status_id', 'ppi_spi_statuses.id')
                    ->select('ppi_spi_statuses.*', 'ppi_spi_notifications.is_read')
                    ->where('ppi_spi_statuses.status_format', 'Main') // Pass the value 'Main' directly
                    ->orderBy('id', 'desc');
            if (auth()->user()->checkRoute($role, "ppi_sent_to_boss_action")) {
                $query = $query->whereNotIn('ppi_spi_statuses.code', ['ppi_sent_to_boss', 'spi_sent_to_boss',  'ppi_sent_to_wh_manager', 'spi_sent_to_wh_manager']);
            }
            if (auth()->user()->checkRoute($role, "ppi_sent_to_wh_manager_action")) {
                $query = $query->whereIn('ppi_spi_statuses.code', ['ppi_sent_to_boss', 'spi_sent_to_boss']);
            }
            if (auth()->user()->checkRoute($role, "ppi_dispute_by_wh_manager_action")) {
                $query = $query->whereIn('ppi_spi_statuses.code', ['ppi_sent_to_wh_manager', 'spi_sent_to_wh_manager']);
            }
            if ($merge['is_read']) {
                $query = $query->whereNull('ppi_spi_notifications.is_read');
            }
            if ($merge['warehouse_id']) {
                $query = $query->where('ppi_spi_statuses.warehouse_id', $merge['warehouse_id']);
            }

          
          	//\Log::info('Notifications Query', ['query' => $query->toSql()]);  // Log the query to the log file
        	//dd($query->paginate(30)); 
          
          
          
            if ($merge['query']) {
                return $query;
            }

            if ($merge['count']) {
                 $query = $query->get();
                 return count($query) ?? null;
             }

             if ($merge['paginate']) {
                 return $query->paginate($merge['paginate']) ?? null;
             } else {
                 return $query->get() ?? null;
             }
        } else{
            return null;
        }

    }

}
